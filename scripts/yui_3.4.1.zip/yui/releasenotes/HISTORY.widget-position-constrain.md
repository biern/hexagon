Widget Position Constrain Change History
========================================

3.4.1
-----

  * No changes.

3.4.0
-----

  * No changes.

3.3.0
-----

  * No changes.

3.2.0
-----

  * No changes.

3.1.1
-----

  * No changes.

3.1.0
-----

  * Initial release.
