Widget Position Change History
==============================

3.4.1
-----

  * No changes.

3.4.0
-----

  * No changes.

3.3.0
-----

  * No changes.

3.2.0
-----

  * No changes.

3.1.1
-----

  * No changes.

3.1.0
-----

  * Relatively positioned bounding boxes, will default to page position instead
    of 0,0

3.0.0
-----

  * Initial release.

  * Fixed ability to set individual x, y values.
