CSS Reset Change History
========================

3.4.1
-----
  * Moved list-type to list declaration.


3.4.0
-----
  * No change.


3.3.0
-----
  * No change.


3.2.0
-----
  * No change.


3.1.1
-----
  * No change.


3.1.0
-----
  * No change.

3.0.0
-----
  * Initial release.

