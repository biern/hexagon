Anim Change History
===================

3.4.1
-----
  * no change


3.4.0
-----
  * no change


3.3.0
-----

  * Bug fix: A glitch occurred when an reversing a previously reversed
    animation. [Ticket 2528581]


3.2.0
-----

  * Bug fix: Better cleanup on destroy. [Ticket 2528820]
  * Bug fix: Was not resuming properly from pause. [Ticket 2528938]


3.1.1
-----
  * no change


3.1.0
-----
  * Now firing the resume event.
  * Added a boolean arg for stop() to force it to skip to the last frame.


3.0.0
-----
  * Initial release.
