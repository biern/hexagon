CSS Base Change History
=======================

3.4.1
-----

  * Bug fix: Nested mixed list types were incorrectly styled. [Ticket 2530302]


3.4.0
-----

  * No code changes.


3.3.0
-----

  * No code changes.


3.2.0
-----

  * No code changes.


3.1.1
-----

  * No code changes.


3.1.0
-----

  * No code changes.
  

3.0.0
-----

  * Initial release.
