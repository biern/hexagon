Panel Change History
====================

3.4.1
-----

  * Panel's CSS related to WidgetButtons has been improved. The styling for
    Panel's header is now much more flexible, while maintaining the position of
    the close button across browsers and varying amounts of content.
    [Ticket #2530978]

  * Panel now has a working Night skin. [Ticket #2530937]

  * The sprite image assets for the "close" button on Panels have moved into the
    WidgetButtons extension's assets. [Ticket #2530952]

  * See also Widget and extensions for changes to dependencies.

3.4.0
-----

  * Initial release.
