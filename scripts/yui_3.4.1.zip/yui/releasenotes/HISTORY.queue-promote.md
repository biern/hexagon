Queue Promote Change History
============================

3.4.1
-----

  * No changes.

3.4.0
-----

  * Fixed bug in `promote()` method where the item moved to the head of the
    queue was wrapped in an array.

3.3.0
-----

  * No changes.

3.2.0
-----

  * No changes.

3.1.1
-----

  * No changes.

3.1.0
-----

  * No changes.

3.0.0
-----

  * `queue-base` is now part of `YUI`. `queue-run` was renamed `async-queue` and
    both it and `queue-promote` are now independent modules.

3.0.0beta1
----------

  * Overhaul: Broken into `queue-base`, `queue-promote`, and `queue-run`.

3.0.0pr2
--------

  * No changes.

3.0.0pr1

  * Initial release.
