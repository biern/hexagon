SWFDetect Utility Change History
================================

3.4.1
-----

  * No changes.

3.4.0
-----

  * No changes.

3.3.0
-----
  * Added API documentation

3.2.0
-----
  *	Contribution by Ryan Cannon: #2529113 fixed logic in isFlashVersionAtLeast() to 
	account for omitted minor and revision versions of the Flash player.

3.1.2
-----
  * No changes
	
3.1.1
-----
   * No changes
	
3.1.0
-----
   * Initial Release