Uploader Utility Change History
===============================

3.4.1
-----
  * No changes in source code
  * Minor example changes

3.4.0
-----
  * No changes

3.3.0
-----
  * Minor changes in documentation

3.2.0
-----
  * Initial release