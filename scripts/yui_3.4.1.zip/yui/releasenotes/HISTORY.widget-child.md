Widget Child Change History
===========================

3.4.1
-----

  * No changes.

3.4.0
-----

  * No changes

3.3.0
-----

  * Changed instanceof to Y.instanceOf, to prevent leaks in IE7

3.2.0
-----

  * No changes

3.1.1
-----

  * No changes

3.1.0
-----

  * Add new ROOT_TYPE property to constrain the behavior of the "root" attribute 
    to instances of a specified type
    
  * Fixes to remove method so that it always returns a reference to the 
    child removed
