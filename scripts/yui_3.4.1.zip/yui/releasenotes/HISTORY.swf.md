SWF Utility Change History
==========================

3.4.1
-----
  * No changes.

3.4.0
-----
  * No changes.

3.3.0
-----
  * Fixed an undefined variable bug
  * Fixes to documentation

3.2.0
-----
  * Added allowedDomain flashvar to pass the security settings to YUIBridge.

3.1.2
-----
  * No changes
	
3.1.1
-----
  * No changes
	
3.1.0
-----
  * Initial Release
