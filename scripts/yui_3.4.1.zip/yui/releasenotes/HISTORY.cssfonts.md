CSS Fonts Change History
========================

3.4.1
-----
  * No change.


3.4.0
-----
  * No change.


3.3.0
-----
  * No change.


3.2.0
-----
  * No change.


3.1.1
-----
  * No change.


3.1.0
-----
  * No change.
  
3.0.0
-----
  * Initial release.
3.0.0PR1 - Initial release

Module Name: "cssfonts"
Documentation: http://developer.yahoo.com/yui/3/cssfonts

The foundational CSS Fonts provides cross-browser 
typographical normalization and control while still 
allowing users to choose and adjust their font size. 
Both Standards and Quirks modes are supported in A-grade browsers.
