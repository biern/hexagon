DataType Change History
=======================

3.4.1
-----
  * No changes

3.4.0
-----

  * Languages are no longer fetch-able for the `datatype-date` module, only for
    the `datatype-date-format` module:

        var availLangs = Y.Intl.getAvailableLangs("datatype-date-format");
    
3.3.0
-----

  * No changes.

3.2.0
-----

  * No changes.

3.1.1
-----

  * No changes.

3.1.0
-----
    
  * Changed to use YUI language resource bundles rather than proprietary
    infrastructure.

3.0.0
-----

  * No changes.

3.0.0beta1
----------

  * Initial release.
