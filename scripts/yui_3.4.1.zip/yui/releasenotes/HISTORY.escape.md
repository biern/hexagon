Escape Change History
=====================

3.4.1
-----

  * No changes.


3.4.0
-----

  * Non-string arguments to `html()` and `regex()` are now coerced to strings.
    [Ticket #2530408]


3.3.0
-----

  * Initial release.
