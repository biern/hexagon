ConsoleFilters Plugin Change History
====================================

3.4.1
-----

  * No changes.

3.4.0
-----

  * No changes.

3.3.0
-----
    
  * No changes.

3.2.0
-----

  * No changes.

3.1.1
-----

  * No changes.

3.1.0
-----

  * Internal reorganization (API and functionality unaffected).

3.0.0
-----

  * Adding attribute `cacheLimit` to limit memory overrun from holding onto all
    log messages.

3.0.0beta1
-----------
    
  * Initial release.
