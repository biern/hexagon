Resize Utility Change History
=============================

### 3.4.1

No changes.

### 3.4.0

   * #2529992 Allow Resizable nodes be used with DD.Delegate
   * #2530007 [Pull Request] - #2529992 Allow Resizable nodes be used with DD.Delegate

### 3.3.0

Initial release
